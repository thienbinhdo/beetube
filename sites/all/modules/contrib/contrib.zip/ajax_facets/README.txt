This module allows you to create facet filter for module search_api_solr by AJAX. 
The module provides a two new widgets for facets:
- Ajax multiple checkboxes.
- Ajax selectbox.