This module provides dailymotion handler for video embed field module
now with this module you can add embed videos from http://www.dailymotion.com
to your website
it also can get thumbnail image from dailymotion
